#!/bin/bash

ip -d -o link show | \
sed -E -e '/loopback\s/d' -e '/\svlan\s/d' -e '/\sbridge/d' -e 's/^\S+:\s(\S+):\s.*/\1/' | \
xargs -I LINK \
ip -o -f inet -h -d addr show LINK | \
sed -e 's/.*inet\s//g' -e 's/\/.*//g' | \
sed ':a; /$/N; s/\n/ \| /; ta'
